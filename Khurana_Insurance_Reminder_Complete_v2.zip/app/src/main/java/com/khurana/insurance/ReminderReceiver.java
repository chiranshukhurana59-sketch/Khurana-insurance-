package com.khurana.insurance;
import android.app.*; import android.content.*; import android.os.*;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){
  String text=i.getStringExtra("text");
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("reminders","Reminders",NotificationManager.IMPORTANCE_HIGH));
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"reminders"):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Khurana Insurance Reminder").setContentText(text).setAutoCancel(true);
  nm.notify((int)System.currentTimeMillis(),b.build());
 }
}