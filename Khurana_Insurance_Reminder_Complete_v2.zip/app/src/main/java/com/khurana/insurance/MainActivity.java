package com.khurana.insurance;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    EditText name,mobile,vehicle,search; Spinner type,before; Button date,add,clear; TextView list;
    String selectedDate=""; ArrayList<String> records=new ArrayList<>(); android.content.SharedPreferences sp;

    String[] types={"Insurance","Pollution / PUC","Vehicle Passing","RC Renewal","Other"};
    String[] days={"30 days before","15 days before","7 days before","3 days before","On expiry date"};

    @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
        name=findViewById(R.id.name); mobile=findViewById(R.id.mobile); vehicle=findViewById(R.id.vehicle);
        search=findViewById(R.id.search); type=findViewById(R.id.type); before=findViewById(R.id.before);
        date=findViewById(R.id.date); add=findViewById(R.id.add); clear=findViewById(R.id.clear); list=findViewById(R.id.list);
        type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types));
        before.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,days));
        sp=getSharedPreferences("data",0); load();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},5);
        date.setOnClickListener(v->pickDate());
        add.setOnClickListener(v->saveRecord());
        clear.setOnClickListener(v->{records.clear(); save(); render();});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){render();} public void afterTextChanged(android.text.Editable e){}});
    }
    void pickDate(){Calendar c=Calendar.getInstance(); new DatePickerDialog(this,(v,y,m,d)->{selectedDate=String.format(Locale.US,"%02d-%02d-%04d",d,m+1,y);date.setText("Expiry: "+selectedDate);},c.get(1),c.get(2),c.get(5)).show();}
    void saveRecord(){
        if(name.getText().toString().trim().isEmpty()||vehicle.getText().toString().trim().isEmpty()||selectedDate.isEmpty()){Toast.makeText(this,"Name, Vehicle and Date fill karo",Toast.LENGTH_SHORT).show();return;}
        String r=name.getText()+"|"+mobile.getText()+"|"+vehicle.getText()+"|"+type.getSelectedItem()+"|"+selectedDate+"|"+before.getSelectedItem();
        records.add(r); save(); render(); scheduleNotification(r); Toast.makeText(this,"Reminder saved",Toast.LENGTH_SHORT).show();
        name.setText(""); mobile.setText(""); vehicle.setText(""); selectedDate=""; date.setText("Select Expiry Date");
    }
    void scheduleNotification(String r){
        try{
            String[] p=r.split("\\|",-1); SimpleDateFormat f=new SimpleDateFormat("dd-MM-yyyy",Locale.US); Date expiry=f.parse(p[4]);
            int idx=before.getSelectedItemPosition(); long minus=idx==0?30L*86400000:idx==1?15L*86400000:idx==2?7L*86400000:idx==3?3L*86400000:0;
            long when=expiry.getTime()-minus; if(when<System.currentTimeMillis()) when=System.currentTimeMillis()+5000;
            Intent i=new Intent(this,ReminderReceiver.class); i.putExtra("text",p[0]+" - "+p[2]+" - "+p[3]);
            PendingIntent pi=PendingIntent.getBroadcast(this,(int)(System.currentTimeMillis()&0x7fffffff),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }catch(Exception e){}
    }
    void load(){records.clear(); try{JSONArray a=new JSONArray(sp.getString("records","[]"));for(int i=0;i<a.length();i++)records.add(a.getString(i));}catch(Exception e){} render();}
    void save(){JSONArray a=new JSONArray();for(String r:records)a.put(r);sp.edit().putString("records",a.toString()).apply();}
    void render(){String q=search.getText().toString().toLowerCase(Locale.ROOT); StringBuilder s=new StringBuilder(); int n=0;
        for(String r:records){String[] p=r.split("\\|",-1); if(q.length()>0 && !(r.toLowerCase(Locale.ROOT).contains(q)))continue; n++;
            s.append(n).append(". ").append(p[0]).append(" | ").append(p[2]).append("\n").append(p[3]).append(" | Expiry: ").append(p[4]).append("\n").append("Reminder: ").append(p[5]).append("\n\n");}
        list.setText(s.length()==0?"No reminders saved":s.toString());
    }
}