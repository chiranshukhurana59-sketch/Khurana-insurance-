KHURANA INSURANCE REMINDER - COMPLETE VERSION 2.0

Features:
- Customer name, mobile and vehicle number
- Insurance / PUC / Passing / RC Renewal / Other
- Expiry date
- Reminder 30/15/7/3 days before or on expiry
- Offline local storage
- Search
- Clear all
- Android notification scheduling

BUILD:
1. Install Android Studio on Windows/Mac.
2. Extract this ZIP.
3. Open the extracted project folder in Android Studio.
4. Wait for Gradle sync.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated APK on Android.

NOTE:
Automatic WhatsApp sending is NOT included. Normal WhatsApp cannot reliably send silent scheduled messages without an approved WhatsApp Business/API service.
